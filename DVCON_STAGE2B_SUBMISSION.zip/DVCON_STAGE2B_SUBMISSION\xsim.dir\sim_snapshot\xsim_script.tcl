xsim {sim_snapshot} -autoloadwcfg -tclbatch {sim/rankmlp_accel_tb.tcl}
